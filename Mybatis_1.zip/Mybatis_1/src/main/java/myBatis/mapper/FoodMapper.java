package myBatis.mapper;

import myBatis.pojo.Food;

import java.util.ArrayList;

public interface FoodMapper {
    // 添加食品
    int selectFood();
    //查询食品
    Food findFood();
    //查询所有食品
    ArrayList<Food> findAllFood();
    //
    Food findFoodById(int id);
}
