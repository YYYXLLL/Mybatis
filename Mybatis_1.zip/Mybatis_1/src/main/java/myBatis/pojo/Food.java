package myBatis.pojo;

public class Food {
    private int id;
    private String FoodName;
    private int FoodType;
    private double Money;

    @Override
    public String toString() {
        return "Food{" +
                "id=" + id +
                ", FoodName='" + FoodName + '\'' +
                ", FoodType=" + FoodType +
                ", Money=" + Money +
                '}';
    }

    public Food() {
    }

    public Food(int id, String foodName, int foodType, double money) {
        this.id = id;
        FoodName = foodName;
        FoodType = foodType;
        Money = money;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFoodName() {
        return FoodName;
    }

    public void setFoodName(String foodName) {
        FoodName = foodName;
    }

    public int getFoodType() {
        return FoodType;
    }

    public void setFoodType(int foodType) {
        FoodType = foodType;
    }

    public double getMoney() {
        return Money;
    }

    public void setMoney(double money) {
        Money = money;
    }
}
