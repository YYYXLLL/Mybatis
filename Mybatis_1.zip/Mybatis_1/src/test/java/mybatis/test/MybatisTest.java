package mybatis.test;

import myBatis.mapper.FoodMapper;
import myBatis.pojo.Food;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class MybatisTest {
    private  static SqlSessionFactory build;
    @Test
    public void testMybits() throws Exception {
        InputStream resourceAsStream = Resources.getResourceAsStream("mybatis-config.xml");
        build = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = build.openSession(true);
        int i = sqlSession.getMapper(FoodMapper.class).selectFood();
        System.out.println(i);

    }
    @Test
    public  void test2() throws IOException {
        InputStream inputStream = Resources.getResourceAsStream("mybatis-config.xml");
        SqlSessionFactory build = new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession = build.openSession(true);
        ArrayList<Food> foods = sqlSession.getMapper(FoodMapper.class).findAllFood();
        foods.forEach(food -> System.out.println(food));
    }
    @Test
    public void test3() throws IOException {
        InputStream resourceAsStream = Resources.getResourceAsStream("mybatis-config.xml");
        build = new SqlSessionFactoryBuilder().build(resourceAsStream);
        SqlSession sqlSession = build.openSession(true);
        Food food = sqlSession.getMapper(FoodMapper.class).findFoodById(11126);
        System.out.println(food);
    }

}
